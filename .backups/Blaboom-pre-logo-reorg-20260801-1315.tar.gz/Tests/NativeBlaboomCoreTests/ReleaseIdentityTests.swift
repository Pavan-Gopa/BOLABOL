import Foundation
import Testing

@Test
func releaseScriptsBuildBlaboomAppWithoutNativePrefix() throws {
    let scriptPaths = [
        "script/build_and_run.sh",
        "script/build_release_dmg.sh"
    ]

    for scriptPath in scriptPaths {
        let source = try String(contentsOfFile: scriptPath, encoding: .utf8)

        #expect(source.contains("SWIFT_PRODUCT_NAME=\"NativeBlaboom\""))
        #expect(source.contains("APP_NAME=\"Blaboom\""))
        #expect(source.contains("DISPLAY_NAME=\"Blaboom\""))
        #expect(source.contains("APP_BUNDLE=\"$"))
        #expect(source.contains("$APP_NAME.app"))
        #expect(source.contains("APP_BINARY=\"$APP_MACOS/$APP_NAME\""))
        #expect(source.contains("<string>$APP_NAME</string>"))
        #expect(!source.contains("APP_NAME=\"NativeBlaboom\""))
    }
}

@Test
func debugRunScriptBuildsAppAndWorkerProductsSeparately() throws {
    let source = try String(contentsOfFile: "script/build_and_run.sh", encoding: .utf8)

    #expect(source.contains("swift build --arch arm64 --product \"$SWIFT_PRODUCT_NAME\""))
    #expect(source.contains("swift build --arch arm64 --product \"$WORKER_NAME\""))
    #expect(!source.contains("swift build --arch arm64 --product \"$SWIFT_PRODUCT_NAME\" --product \"$WORKER_NAME\""))
}

@Test
func releaseDmgUsesBlaboomFilename() throws {
    let source = try String(contentsOfFile: "script/build_release_dmg.sh", encoding: .utf8)

    #expect(source.contains("OUTPUT_DMG=\"$DIST_DIR/Blaboom.dmg\""))
    #expect(!source.contains("OUTPUT_DMG=\"$DIST_DIR/NativeBlaboom.dmg\""))
}

@Test
func glossaryExportDefaultsUseBlaboomFilename() throws {
    let source = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/Settings/GlossarySettingsView.swift",
        encoding: .utf8
    )

    #expect(source.contains("Blaboom-glossary.json"))
    #expect(source.contains("Blaboom-glossary.csv"))
    #expect(!source.contains("NativeBlaboom-glossary"))
}

@Test
func distributedLogoLookupDoesNotUseSwiftPMModuleBundle() throws {
    let source = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/Components/BlaboomLogoView.swift",
        encoding: .utf8
    )

    #expect(source.contains("Bundle.main.url(forResource: \"BLABOOM_LOGO\", withExtension: \"svg\")"))
    #expect(!source.contains("Bundle.module"))
}

@Test
func fullLogoLookupDoesNotUseSwiftPMModuleBundle() throws {
    let source = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/Components/BlaboomFullLogoView.swift",
        encoding: .utf8
    )

    #expect(source.contains("Bundle.main.url(forResource: \"BLABOOM_LOGO_Full\", withExtension: \"svg\")"))
    #expect(!source.contains("Bundle.module"))
}

@Test
func wordmarkLogoLookupDoesNotUseSwiftPMModuleBundle() throws {
    let source = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/Components/BlaboomWordmarkView.swift",
        encoding: .utf8
    )

    #expect(source.contains("Bundle.main.url(forResource: \"BLABOOM_Wordmark\", withExtension: \"svg\")"))
    #expect(!source.contains("Bundle.module"))
}

@Test
func mainWindowPlacesWordmarkInTitleBarInsteadOfNoteContent() throws {
    let contentView = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/ContentView.swift",
        encoding: .utf8
    )
    let noteDetailView = try String(
        contentsOfFile: "Sources/NativeBlaboom/Views/NoteDetailView.swift",
        encoding: .utf8
    )
    let appSource = try String(
        contentsOfFile: "Sources/NativeBlaboom/App/NativeBlaboomApp.swift",
        encoding: .utf8
    )

    #expect(!contentView.contains("BlaboomWordmarkView"))
    #expect(noteDetailView.contains("ToolbarItem(placement: .navigation)"))
    #expect(noteDetailView.contains("BlaboomWordmarkView(height: 18)"))
    #expect(appSource.contains("window.titleVisibility = .hidden"))
}

@Test
func statusBarIconLookupDoesNotUseSwiftPMModuleBundle() throws {
    let source = try String(
        contentsOfFile: "Sources/NativeBlaboom/App/NativeBlaboomApp.swift",
        encoding: .utf8
    )

    #expect(source.contains("bundledImage(named: \"BLABOOM_status_bar_icon\", extension: \"svg\")"))
    #expect(!source.contains("Bundle.module"))
}

@Test
func releaseDmgEmbedsSwiftCompatibilityRuntime() throws {
    let source = try String(contentsOfFile: "script/build_release_dmg.sh", encoding: .utf8)

    #expect(source.contains("APP_FRAMEWORKS=\"$APP_CONTENTS/Frameworks\""))
    #expect(source.contains("xcrun swift-stdlib-tool --print"))
    #expect(source.contains("cp \"$swift_library\" \"$APP_FRAMEWORKS/\""))
    #expect(source.contains("@executable_path/../Frameworks/libswiftCompatibilitySpan.dylib"))
    #expect(source.contains("install_name_tool -delete_rpath \"$xcode_swift62_rpath\""))
    #expect(source.contains("codesign_release \"$dylib\""))
}
